"""
Module for data loading and preprocessing

Here register custom cross-validation splitters.
"""

from .sklearn_splitter import *
from .splitter import *
